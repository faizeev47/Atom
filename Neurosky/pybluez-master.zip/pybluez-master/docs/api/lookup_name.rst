lookup_name
-----------
.. currentmodule:: bluetooth

.. autofunction:: lookup_name